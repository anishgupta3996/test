package com.lostfound.dto;

public class APIResponse1 {

	private String responseCode;
	private Boolean error;
	private String errorMessage;
/*	private Object tempo;
	private Object tempoforchar;

	public Object getTempoforchar() {
		return tempoforchar;
	}

	public void setTempoforchar(Object tempoforchar) {
		this.tempoforchar = tempoforchar;
	}

	public Object getTempo() {
		return tempo;
	}

	public void setTempo(Object tempo) {
		this.tempo = tempo;
	}
*/
	public Boolean getError() {
		return error;
	}

	public void setError(Boolean error) {
		this.error = error;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
