/**
 * @author ayush.deep
 */
package com.lostfound.entity;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transient")
public class CustomerClaim {
	@NotNull
	private String name;
	@NotNull
	private String anish;
	@Transient
	@NotNull
	private List<CustomerClaim> comments = new ArrayList<CustomerClaim>();


 

public List<CustomerClaim> getComments() {
		return comments;
	}

	public void setComments(List<CustomerClaim> comments) {
		this.comments = comments;
	}

public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAnish() {
		return anish;
	}

	public void setAnish(String anish) {
		this.anish = anish;
	}

}
