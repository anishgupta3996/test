/**
 * @author ayush.deep
 */
package com.lostfound.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lostfound.entity.CustomerClaim;
@Repository
public interface CustomerClaimRepository extends MongoRepository<CustomerClaim, String>{

	
	
}
