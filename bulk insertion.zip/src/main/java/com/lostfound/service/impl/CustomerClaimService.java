/**
 * @author ayush.deep
 */
package com.lostfound.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.lostfound.comman.Constants;
import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim;
import com.lostfound.repository.CustomerClaimRepository; 
import com.lostfound.service.ICustomerClaimService;

@Service
public class CustomerClaimService implements ICustomerClaimService {
 
	@Autowired
	CustomerClaimRepository customerClaimRepo;
	 
	@Autowired
	private Environment environment;
	@Override
	public ResponseEntity<APIResponse1> saveCustomerClaim(@RequestBody CustomerClaim customerClaim) {
		APIResponse1 apiResponse = new APIResponse1();
		/*for (int i = 0; i < customerClaim.getComments().size(); i++) {
			
			customerClaimRepo.save(customerClaim.getComments().set(i, customerClaim));
		}
		*/
		/*customerClaimRepo.save(customerClaim);*/
		try {
		customerClaimRepo.saveAll(customerClaim.getComments());
		//customerClaimRepo.save(customerClaim);
		apiResponse.setResponseCode(environment.getProperty(Constants.api_success_response));
		apiResponse.setError(false);
		apiResponse.setErrorMessage(environment.getProperty(Constants.api_noexception_message));
		return new ResponseEntity<APIResponse1>(apiResponse, HttpStatus.OK);
		
		}
		catch (Exception e) {
			apiResponse.setError(true);
			apiResponse.setErrorMessage(e.getMessage());
			apiResponse.setResponseCode(environment.getProperty(Constants.api_internalservererror_response));
			apiResponse.setResponseCode("Exception occured");
			return new ResponseEntity<APIResponse1>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	

	}



}