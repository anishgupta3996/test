/**
 * @author ayush.deep
 */
package com.lostfound.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim;
import com.lostfound.service.ICustomerClaimService;

@RestController
@RequestMapping("/api")
public class CustomerClaimController {
	@Autowired
	ICustomerClaimService customerClaimService;

	@RequestMapping(value = "/customerclaim", method = RequestMethod.POST)
	public ResponseEntity<APIResponse1> getFr24Data(@RequestBody CustomerClaim customerClaim) {
		
		return customerClaimService.saveCustomerClaim(customerClaim);
	}

	
	
	
	
}
