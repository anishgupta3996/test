package com.lostfound.learning;

public class OTP {

	private static int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

	public static String getOTP(int size) {

		final StringBuffer otp = new StringBuffer();

		if (size != 0) {

			for (int i = 0; i < size; i++) {

				otp.append(numbers[(int) (Math.random() * numbers.length)]);
			}

			return otp.toString();
		}

		return "INVAILD";
	}

	public static void main(String[] args) {

		System.out.println(getOTP(4));
		System.out.println(getOTP(5));
		System.out.println(getOTP(6));
		System.out.println(getOTP(7));
		System.out.println(getOTP(8));
	}

}