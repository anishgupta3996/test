/**
 * @author ayush.deep
 */
package com.lostfound.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lostfound.entity.recordItems;
 
@Repository
public interface recordItemsRepository  extends MongoRepository<recordItems, String>{

	
	
}
