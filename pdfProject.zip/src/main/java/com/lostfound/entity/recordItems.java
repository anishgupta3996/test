/**
 * @author ayush.deep
 */
package com.lostfound.entity;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "pdfproject")
public class recordItems  {
	private Integer serial_no;
	private String date;
	private String flight_no;
	

	public Integer getSerial_no() {
		return serial_no;
	}

	public void setSerial_no(Integer serial_no) {
		this.serial_no = serial_no;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getFlight_no() {
		return flight_no;
	}

	public void setFlight_no(String flight_no) {
		this.flight_no = flight_no;
	}

}
