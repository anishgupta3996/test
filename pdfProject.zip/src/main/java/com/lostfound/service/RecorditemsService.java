/**
 * @author ayush.deep
 */
package com.lostfound.service;

import java.util.List;

import com.lostfound.entity.recordItems;

public interface RecorditemsService  {
	List<recordItems> findAll();
	
}
