package com.lostfound.service.impl;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.lostfound.entity.recordItems;
import com.lostfound.learning.HeaderFooterPageEvent;
import com.lostfound.repository.recordItemsRepository;
import com.lostfound.service.RecorditemsService;


import javassist.Modifier;

@Service
public class RecordItemServiceImpl implements RecorditemsService{
	
	@Autowired
	recordItemsRepository recorditemsrepository;

	@Override
	public List<recordItems> findAll() {
			int count=0;
			
			String airport_name;
			String airport_port;
			int srno;
		List<String> feildname=new ArrayList<String>() ;
		List<recordItems> ri=recorditemsrepository.findAll();
		 Document document = new Document(PageSize.A4,50, 45, 85, 60);
		try {
		
			PdfWriter writer =PdfWriter.getInstance(document, new FileOutputStream("file.pdf"));
			
	
		
			   HeaderFooterPageEvent event = new HeaderFooterPageEvent();
		        writer.setPageEvent(event);
		        document.open();

		        document.setMarginMirroring(false);

		     
		        
			PdfPTable table=new PdfPTable(3);
			table.setWidthPercentage(105);
			table.setSpacingBefore(60f);
			table.setSpacingAfter(30f);
			float[] colWidth= {2f,2f,2f};
			table.setWidths(colWidth);
		
			
			for (Field field : recordItems.class.getDeclaredFields()) 
			{
				if (Modifier.isPrivate(field.getModifiers()))
				{
					count=count+1;
					feildname.add(field.getName());
				}
			}
	
			for(int i=0;i <feildname.size();i++) 
			{
				PdfPCell c1 = new PdfPCell(new Paragraph(feildname.get(i)));
				table.addCell(c1);
			}
			for(int i=0;i< ri.size();i++)
			{
				airport_name=ri.get(i).getDate();
				airport_port=ri.get(i).getFlight_no();
				srno=ri.get(i).getSerial_no();
				table.addCell(String.valueOf(srno));
				table.addCell(airport_name);
				table.addCell(airport_port);
				
			}
		
			document.add(table);
			/*PdfReader reader=new PdfReader(SRC)	;
			int n=		reader.getNumberOfPages();
			System.out.println(n);*/
			document.close();
			writer.close();
			
			
		}catch(DocumentException e)
		{
			e.printStackTrace();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ri;
	}
	
}
