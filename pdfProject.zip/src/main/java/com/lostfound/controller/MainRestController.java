/**
 * @author ayush.deep
 */
package com.lostfound.controller;

 

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lostfound.entity.recordItems;
import com.lostfound.repository.recordItemsRepository;
import com.lostfound.service.RecorditemsService;
 

@RestController
public class MainRestController {

	@Autowired
	recordItemsRepository recorditemsrepository;
	 
	@Autowired
	private RecorditemsService recorditemsService;
@CrossOrigin
	@RequestMapping("/details")
	public ResponseEntity<InputStreamResource> download1() throws FileNotFoundException {
        final File file = new File("file.pdf");
        recorditemsService.findAll()       ;
        return ResponseEntity.ok().contentLength(file.length())
                .contentType(MediaType.APPLICATION_PDF)
                .cacheControl(CacheControl.noCache())
                .header("Content-Disposition", "attachment; filename=" + file.getName())
                .body(new InputStreamResource(new FileInputStream(file)));
                

}
	
	/*@CrossOrigin
	@RequestMapping("/details")
	  public List<recordItems>  viewAll() {
			List<recordItems> users = recorditemsService.findAll();
			return users;
	  }
*/
	
	
}