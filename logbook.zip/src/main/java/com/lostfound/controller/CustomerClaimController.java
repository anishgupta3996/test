/**
 * @author ayush.deep
 */
package com.lostfound.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim;
import com.lostfound.entity.CustomerClaim1;
import com.lostfound.service.ICustomerClaimService;

@RestController
@RequestMapping("/api")
public class CustomerClaimController {
	@Autowired
	ICustomerClaimService customerClaimService;

	@RequestMapping(value = "/customerclaim", method = RequestMethod.POST)
	public ResponseEntity<APIResponse1> getFr24Data(@RequestBody CustomerClaim customerClaim ) {

		return customerClaimService.saveCustomerClaim(customerClaim );
	}

	@RequestMapping(value = "/customerclaim1", method = RequestMethod.POST)
	public List<Date> getFr24Data1(@RequestBody CustomerClaim customerClaim ) {

	
		return customerClaimService.getDatesBetweenUsingJava7(customerClaim.getD1(),customerClaim.getD2());
	}
}
