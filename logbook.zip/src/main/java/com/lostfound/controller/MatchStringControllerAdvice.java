package com.lostfound.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.lostfound.comman.Constants;
import com.lostfound.dto.APIResponse1;

public class MatchStringControllerAdvice {

	@Autowired
	private Environment environment;

	@ExceptionHandler(HttpMessageNotReadableException.class)
	/**
	 * 
	 * @param exception
	 * @return
	 */
	public ResponseEntity<APIResponse1> handleException(HttpMessageNotReadableException exception) {
		APIResponse1 exceptionResponse = new APIResponse1();
		exceptionResponse.setResponseCode(environment.getProperty(Constants.api_badrequest_response));
		exceptionResponse.setErrorMessage(exception.getMessage());
		exceptionResponse.setError(true);
		return new ResponseEntity<APIResponse1>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
}
