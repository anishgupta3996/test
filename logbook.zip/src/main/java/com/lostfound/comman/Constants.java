package com.lostfound.comman;

public class Constants {
	public static final String api_noexception_message = "api.noexception.message";
	public static final String api_success_response = "api.response.code.success";
	public static final String api_badrequest_response = "api.response.code.badrequest";
	public static final String api_internalservererror_response = "api.response.code.internalservererror";
	public static final String api_unauthorized_response = "api.response.code.unauthorized";
}
