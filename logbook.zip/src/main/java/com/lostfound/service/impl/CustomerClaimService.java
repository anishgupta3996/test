/**
 * @author ayush.deep
 */
package com.lostfound.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.lostfound.comman.Constants;
import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim;
import com.lostfound.entity.CustomerClaim1;
import com.lostfound.repository.CustomerClaimRepository;
import com.lostfound.repository.CustomerClaimRepository1;
import com.lostfound.service.ICustomerClaimService;

@Service
public class CustomerClaimService implements ICustomerClaimService {

	@Autowired
	CustomerClaimRepository customerClaimRepo;
	@Autowired
	CustomerClaimRepository1 customerClaimRepo1;
	@Autowired
	private Environment environment;

	@Override
	public ResponseEntity<APIResponse1> saveCustomerClaim(@RequestBody CustomerClaim customerClaim) {
		
		APIResponse1 apiResponse = new APIResponse1();
		/*String usernme="anish";
		String password="anish17018";*/

		try {

			/*
			 * CustomerClaim1 customerClaim1=new CustomerClaim1();
			 * customerClaim1.setDate(customerClaim.getDate());
			 * customerClaim1.setName(customerClaim.getName());
			 * customerClaim1.setResp(customerClaim.getResp());
			 * customerClaim1.setShift(customerClaim.getShift());
			 * customerClaimRepo.save(customerClaim);
			 */
			System.out.println(customerClaim.getUsername());
			
			System.out.println(customerClaim.getPassword());
					
			
			if(customerClaim.getUsername().equals("anish") && customerClaim.getPassword().equals("anish17018")) {
				System.out.println("userid password matched");
			Date date = new Date();
			SimpleDateFormat formatter1 = new SimpleDateFormat("MM-dd-yyyy hh:mm a");
			SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy hh:mm a");
			formatter1.setTimeZone(TimeZone.getTimeZone("IST"));
			formatter2.setTimeZone(TimeZone.getTimeZone("UTC"));
			System.out.println("IST TIME IS   " +formatter1.format(date));
			System.out.println("UTC TIME IS   "+formatter2.format(date));
			String string_timestamp = formatter1.format(date).substring(11);
			String string_datestamp = formatter1.format(date).substring(0, 10);
			System.out.println("TIMESTAMP IS = " + string_timestamp);
			System.out.println("DATESTAMP IS = " + string_datestamp);

			String string1 = "08:30 AM";
			Date time1 = new SimpleDateFormat("hh:mm a").parse(string1);
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(time1);

			String string2 = "09:30 PM";
			Date time2 = new SimpleDateFormat("hh:mm a").parse(string2);
			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(time2);
			calendar2.add(Calendar.DATE, 1);

			String someRandomTime = string_timestamp;
			Date d = new SimpleDateFormat("hh:mm a").parse(someRandomTime);
			Calendar calendar3 = Calendar.getInstance();
			calendar3.setTime(d);
			calendar3.add(Calendar.DATE, 1);

			Date x = calendar3.getTime();
			if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
				
				System.out.println("MORNING");	
				customerClaim.setShift("MORNING");
				customerClaim.setRsp("task for java");
				customerClaim.setEntitydate(string_datestamp);
				customerClaim.setEntityyime(string_timestamp);
				customerClaimRepo.save(customerClaim);
			} else {
				System.out.println("evening");
				customerClaim.setShift("Evening");
				customerClaim.setRsp("task for database");
				customerClaim.setEntitydate(string_datestamp);
				customerClaim.setEntityyime(string_timestamp);
				customerClaimRepo.save(customerClaim);
			}
			apiResponse.setResponseCode(environment.getProperty(Constants.api_success_response));
			apiResponse.setError(false);
			apiResponse.setErrorMessage(environment.getProperty(Constants.api_noexception_message));
			return new ResponseEntity<APIResponse1>(apiResponse, HttpStatus.OK);
			 }
			 else {
				 System.out.println("userid password not matched");
				 apiResponse.setError(true);
					//apiResponse.setErrorMessage(e.getMessage());
					apiResponse.setResponseCode(environment.getProperty(Constants.api_internalservererror_response));
					apiResponse.setResponseCode("userid password not matched");
					return new ResponseEntity<APIResponse1>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			 }
			

		} catch (Exception e) {
			apiResponse.setError(true);
			apiResponse.setErrorMessage(e.getMessage());
			apiResponse.setResponseCode(environment.getProperty(Constants.api_internalservererror_response));
			apiResponse.setResponseCode("Exception occured");
			return new ResponseEntity<APIResponse1>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	public  List<Date> getDatesBetweenUsingJava7(Date startDate, Date endDate) {
		List<CustomerClaim> findAll = customerClaimRepo.findAll();
					    List<Date> datesInRange = new ArrayList<>();
			    Calendar calendar = new GregorianCalendar();
			    calendar.setTime(startDate);
			     
			    Calendar endCalendar = new GregorianCalendar();
			    endCalendar.setTime(endDate);
			 
			    while (calendar.before(endCalendar)) {
			        Date result = calendar.getTime();
			        datesInRange.add(result);
			        calendar.add(Calendar.DATE, 1);
			    }
			    return datesInRange;
			}
}