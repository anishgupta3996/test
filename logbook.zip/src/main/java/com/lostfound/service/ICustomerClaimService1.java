/**
 * @author ayush.deep
 */
package com.lostfound.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim1; 

public interface ICustomerClaimService1 {
	
	public /*List<Test11>*/ ResponseEntity<APIResponse1>  saveCustomerClaim( @RequestBody CustomerClaim1 customerClaim);
}
