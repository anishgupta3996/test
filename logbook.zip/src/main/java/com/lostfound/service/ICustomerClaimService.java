/**
 * @author ayush.deep
 */
package com.lostfound.service;

import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.lostfound.dto.APIResponse1;
import com.lostfound.entity.CustomerClaim;
import com.lostfound.entity.CustomerClaim1; 

public interface ICustomerClaimService {
	
	public /*List<Test11>*/ ResponseEntity<APIResponse1>  saveCustomerClaim( @RequestBody CustomerClaim customerClaim );
	public List<Date> getDatesBetweenUsingJava7(Date startDate, Date endDate);
}
