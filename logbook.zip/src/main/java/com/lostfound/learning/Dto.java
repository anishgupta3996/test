package com.lostfound.learning;

import com.lostfound.entity.CustomerClaim;
import com.lostfound.entity.CustomerClaim1;

public class Dto {

	CustomerClaim customerClaim;
	CustomerClaim1 customerClaim1;
	public CustomerClaim getCustomerClaim() {
		return customerClaim;
	}
	public void setCustomerClaim(CustomerClaim customerClaim) {
		this.customerClaim = customerClaim;
	}
	public CustomerClaim1 getCustomerClaim1() {
		return customerClaim1;
	}
	public void setCustomerClaim1(CustomerClaim1 customerClaim1) {
		this.customerClaim1 = customerClaim1;
	}
	
	
	
	
}
