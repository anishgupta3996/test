package com.lostfound.learning;

public class OTP {

	public static void main(String[] args) {

	}

}