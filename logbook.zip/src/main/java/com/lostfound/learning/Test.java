package com.lostfound.learning;

import java.util.Date;

public class Test {

	public static void main(String[] args)   {
Date date=new Date();

	}

}
