/**
 * @author ayush.deep
 */
package com.lostfound.entity;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "elogbook2")
public class CustomerClaim1 {
	@Id
	private String id;
	@NotNull
	private String name;
	@NotNull
	private String shift;
	@NotNull
	private String date;
	@NotNull
	private String resp;
/*	@Transient
	@NotNull
	private List<CustomerClaim> comments = new ArrayList<CustomerClaim>();*/

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getResp() {
		return resp;
	}
	public void setResp(String resp) {
		this.resp = resp;
	}

 

 
/*public List<CustomerClaim> getComments() {
		return comments;
	}

	public void setComments(List<CustomerClaim> comments) {
		this.comments = comments;
	}*/
	
	 
}
