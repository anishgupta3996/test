/**
 * @author ayush.deep
 */
package com.lostfound.entity;
import java.time.LocalDateTime;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "time")
public class CustomerClaim {
	@Id
	private String id;
	private String rsp;
	private String shift;
	private String username;
	private String password;
	private String entitydate;
	private String entityyime;
	private Date d1;
	private Date d2;
	
	
	
	
	
public Date getD1() {
		return d1;
	}
	public void setD1(Date d1) {
		this.d1 = d1;
	}
	public Date getD2() {
		return d2;
	}
	public void setD2(Date d2) {
		this.d2 = d2;
	}
public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


public String getEntitydate() {
	return entitydate;
}
public void setEntitydate(String entitydate) {
	this.entitydate = entitydate;
}
public String getEntityyime() {
	return entityyime;
}
public void setEntityyime(String entityyime) {
	this.entityyime = entityyime;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getRsp() {
	return rsp;
}
public void setRsp(String rsp) {
	this.rsp = rsp;
}
public String getShift() {
	return shift;
}
public void setShift(String shift) {
	this.shift = shift;
}

	/*@Id
	private String id;
	@NotNull
	private String name;
	@NotNull
	private String shift;
	@NotNull
	private String date;
	@NotNull
	private String resp;
	@Transient
	@NotNull
	private List<CustomerClaim> comments = new ArrayList<CustomerClaim>();

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getResp() {
		return resp;
	}
	public void setResp(String resp) {
		this.resp = resp;
	}

 
*/
 
/*public List<CustomerClaim> getComments() {
		return comments;
	}

	public void setComments(List<CustomerClaim> comments) {
		this.comments = comments;
	}*/
	
	 
}
