/**
 * @author ayush.deep
 */
package com.navtech.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.navtech.DTO.ResponseDTO;
import com.navtech.exception.UnAuthorizedException;





@Component
public class CommonResponse {

	@Value("${api.response.code.success}")
	private int successCode;
	@Value("${api.response.code.internalservererror}")
	private int internalServerErrorCode;
	@Value("${api.response.code.badrequest}")
	private int badRequestCode;
	@Value("${api.response.code.unauthorized}")
	private int unauthorized;
	@Value("${api.response.message.success}")
	private String successMessage;
	@Value("${api.response.message.failure}")
	private String failureMessage;
	
	@Value("${unauthorized_access_message}")
	private String unauthorizedAccessMessage;
	
	/**
	 * Method to set Failure or Success response object
	 * @param data
	 * @param exception
	 * @return
	 */
	public ResponseDTO setResponseObject(Object data, Exception exception) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setData(data);
		if (exception == null) {
			responseDTO.setError(false);
			responseDTO.setErrorMessage(null);
			responseDTO.setResponseCode(successCode);
			responseDTO.setResponseMessage(successMessage);
		} else {
			responseDTO.setError(true);
			responseDTO.setErrorMessage(exception.getMessage());
			responseDTO.setResponseCode(internalServerErrorCode);
			responseDTO.setResponseMessage(failureMessage);
		}

		return responseDTO;
	}

	
	/**
	 * Method for UnAuthorizedAccess Or Bad Request
	 * @param exception
	 * @return
	 */
	public ResponseDTO setResponseObjectUnAuthorizedBadRequest(Exception exception) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setData(null);
		responseDTO.setError(true);
		responseDTO.setErrorMessage(exception.getMessage());
		if (exception.getClass().equals(UnAuthorizedException.class)) {
			responseDTO.setResponseCode(unauthorized);
		} else {
			responseDTO.setResponseCode(badRequestCode);
		}

		responseDTO.setResponseMessage(failureMessage);
		return responseDTO;
	}
	
	
	/**
	 * In case of Invalid Request Header
	 * @return
	 */
	public ResponseEntity<ResponseDTO> inValidRequestHeader() {
		/**
		 * Every API request has to check for authentication of this token
		 */
		return new ResponseEntity<ResponseDTO>(
					setResponseObjectUnAuthorizedBadRequest(
							new UnAuthorizedException(unauthorizedAccessMessage)),
					HttpStatus.UNAUTHORIZED);
		
	}
	
	/**
	 * In case of run time exception (Caught)- Internal Server Error
	 * @param exception
	 * @return
	 */
	public ResponseEntity<ResponseDTO> internalServerError(Exception exception){
		return new ResponseEntity<ResponseDTO>(setResponseObject(null, exception), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
