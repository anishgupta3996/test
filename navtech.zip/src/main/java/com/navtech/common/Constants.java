/**
 * @author ayush.deep
 */
package com.navtech.common;

public class Constants {

	/**
	 * Below Constants Added By Ayush for Navtech Service
	 */
	private Constants() {
		// Private Constructor to hide the implicit one
	}

	public static final String SFTP_HOST = "sftp.host";
	public static final String SFTP_USER = "sftp.user";
	public static final String SFTP_PASSWORD = "sftp.password";
	public static final String SFTP_PORT = "sftp.port";
	public static final String SFTP_WORKING_DIRECTORY = "sftp.working.directory";
	public static final String SFTP_FILENAME_PREFIX = "sftp.filename.prefix";
	public static final String SFTP_FILDOWNLOAD_LOCAL_PATH = "sftp.filedownload.local.path";
	public static final String SFTP_FILDOWNLOAD_LOCAL_EXTENSION = "sftp.filedownload.local.extension";

	public static final String NAVTECH_FEED_REQUEST_SECONDS = "navtech.feed.request.seconds";
	public static final String ARMS_FEED_REQUEST_SECONDS = "arms.feed.request.seconds";

	public static final String ARMS_API_URL = "arms.api.url";

	public static final String ARMS_NAVTECH_INTEGRATE_REQUEST_SECONDS = "armsnavtechintegrate.feed.request.second";

	public static final String SEND_MAIL_FROM = "send.mail.from";
	public static final String SEND_MAIL_APPLICATION_KEY = "send.mail.application.key";
	public static final String SEND_EMAIL_SUBJECT = "send.mail.subject";
}
