/**
 * @author ayush.deep
 */
package com.navtech.common;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.navtech.entity.Nullnav;
import com.navtech.model.SendEmailApi;

@Component
public class SendMailAPI {

	private Logger log = Logger.getLogger(SendMailAPI.class);

	@Autowired
	private Environment environment;
	@Value("${sendmail.to.azure.api}")
	private String sendemailUrl;

	@Value("${mail.to.list}")
	private String[] mailToList;

	public void sendMailNetCoreAPI(StringBuilder emailBody) {
		/**
		 * This method was added by Ayush to send mail without use of Direct SMTP
		 * instead sending the request to another server with SMTP
		 */

		try {
			String temp = "";
			SendEmailApi emailAPi = new SendEmailApi();
			emailAPi.setApplicationKey(environment.getProperty(Constants.SEND_MAIL_APPLICATION_KEY));
			emailAPi.setFrom(environment.getProperty(Constants.SEND_MAIL_FROM));
			emailAPi.setTo(mailToList);
			emailAPi.setHtmlContent(emailBody.toString());
			emailAPi.setPlainTextContent(" ");
			emailAPi.setSubject(environment.getProperty(Constants.SEND_EMAIL_SUBJECT));
			// Set Your Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			RestTemplate restTemplate = new RestTemplate();
			@SuppressWarnings({ "unchecked", "rawtypes" })
			HttpEntity entity = new HttpEntity(emailAPi, headers);
			/*restTemplate.exchange(sendemailUrl, HttpMethod.POST, entity, String.class);*/
			log.info("Mail Was Sent Successfully" + temp);
		} catch (Exception e) {
			log.info("Exception occured While Sending Mail" + e.getMessage());
			throw new RuntimeException(e);
		}

	}

	public StringBuilder getMailTemplate(List<Nullnav> nullNavList) throws Exception {

		StringBuilder email = new StringBuilder();

		email.append(
				"<html><body>Hello Team,<br>Please find the list of missing Flight Detail files from Navtech.<br><br><br>"
						+ "<table width = '100%' style='border:2px solid black'>");
		email.append("<tr><th>Flight Number</th><th>Departure Time</th><th>Departure Date</th>");
		for (int i = 0; i < nullNavList.size(); i++) {
			email.append("<tr bgcolor=\"#CCD1D1\">");
			email.append("<td align='center'>");
			email.append(nullNavList.get(i).getFlightNumber());
			email.append("</td>");
			email.append("<td align='center'>");
			email.append(nullNavList.get(i).getStd());
			email.append("</td>");
			email.append("<td align='center'>");
			email.append(nullNavList.get(i).getDepartureDate());
			email.append("</td>");
			email.append("</tr>");
		}
		email.append("</table></body></html>");
		return email;

	}

}
