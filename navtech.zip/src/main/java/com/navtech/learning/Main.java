package com.navtech.learning;

 class Parent{
	 int x=10;
	 void parent(int a) {
		 System.out.println("a="+a);
	 }
	 void display() {
		 System.out.println("display of parent");
	 }
 }
 class Child extends Parent{
	 int x=15;
	 void display() {
		 System.out.println("display of child");
	 }
}

class Main {
	public static void main(String[] args) {
	Child c=new Child();	
	System.out.println(c.x);
	c.display();
	c.parent(2);
	}
}
