package com.navtech.service;

import org.springframework.http.ResponseEntity;

import com.navtech.DTO.ResponseDTO;

public interface IArmsFetchService {
	void unmarshall();
	ResponseEntity<ResponseDTO> findBydateString(String dateString);
}
