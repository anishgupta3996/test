package com.navtech.service;

import org.springframework.http.ResponseEntity;

import com.navtech.DTO.ResponseDTO;

public interface INavArmsIntegrateService {
	void integrateARMSWithNavtech();
	
	ResponseEntity<ResponseDTO> findBydateString(String dateString);
}
