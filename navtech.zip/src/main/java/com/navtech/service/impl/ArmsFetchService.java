package com.navtech.service.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.navtech.DTO.ResponseDTO;
import com.navtech.arms.model.ArrayOfFlightDetails;
import com.navtech.common.CommonResponse;
import com.navtech.common.Constants;
import com.navtech.entity.Arms;
import com.navtech.repository.IArmsRepository;
import com.navtech.service.IArmsFetchService;

@Service
public class ArmsFetchService implements IArmsFetchService {

	private Logger log = Logger.getLogger(ArmsFetchService.class);
	@Autowired
	private Environment environment;
	@Autowired
	CommonResponse commonResponse;

	@Autowired
	IArmsRepository armsRepo;

	@Override
	public void unmarshall() {
		try {

			Date todaydate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
			formatter.setTimeZone(TimeZone.getTimeZone("IST"));
			String currentDate = formatter.format(todaydate);
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("FlightDate", currentDate);
			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
			ResponseEntity<String> response = restTemplate
					.postForEntity(environment.getProperty(Constants.ARMS_API_URL), request, String.class);
			ArrayOfFlightDetails flights = getFlightDetails(response.getBody());
			flights.getFlightDetails().stream().filter(e -> {
				e.setFlightMembers(null);
				e.setDelays(null);
				return true;
			}).collect(Collectors.toList());
			saveArmsToDB(flights.getFlightDetails());
		} catch (Exception exception) {
			log.info("Exception Occured While Saving Arms Details" + exception);
			throw new RuntimeException(exception);
		}

	}

	private ArrayOfFlightDetails getFlightDetails(String responseBody) throws JAXBException {
		InputStream stream = new ByteArrayInputStream(responseBody.getBytes(StandardCharsets.UTF_8));
		return (ArrayOfFlightDetails) unmarshal(ArrayOfFlightDetails.class, stream);

	}

	private Object unmarshal(Class<?> className, InputStream inputStream) throws JAXBException {
		JAXBContext jaxbContext;
		jaxbContext = JAXBContext.newInstance(className);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return jaxbUnmarshaller.unmarshal(inputStream);
	}

	private void saveArmsToDB(List<ArrayOfFlightDetails.FlightDetails> flightDetails) {
		for (ArrayOfFlightDetails.FlightDetails result : flightDetails) {
			try {
				Arms arms = new Arms();
				arms.setAta(result.getATA());
				arms.setAtd(result.getATD());
				arms.setEta(result.getETA());
				arms.setEtd(result.getETD());
				arms.setSta(result.getSTA());
				arms.setStd(result.getSTD());
				arms.setFlightNumber(result.getFlightNo());
				arms.setDepartureDate(result.getDepartureDate());
				arms.setDateString(java.time.LocalDate.now().toString());
				/**
				 * Also get data from database on basis of departure date and flight number
				 */
				Optional<Arms> dbResult = armsRepo.findByDepartureDateAndFlightNumber(result.getDepartureDate(),
						result.getFlightNo());
				if (dbResult.isPresent() && dbResult.get().getId() != null) {
					// Remove the previous one as ATA,ETA or STA might have been updated
					armsRepo.delete(dbResult.get());
				}
				armsRepo.save(arms);
			} catch (Exception exception) {
				log.info("Exception Occured During Saving Arms Data" + exception);
				continue;
			}
		}

	}

	@Override
	public ResponseEntity<ResponseDTO> findBydateString(String dateString) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			responseDTO = commonResponse.setResponseObject(armsRepo.findByDateString(dateString), null);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception exception) {
			log.info("Exception Occured While Fetching Arms Details" + exception);
			return commonResponse.internalServerError(exception);
		}
	}

}
