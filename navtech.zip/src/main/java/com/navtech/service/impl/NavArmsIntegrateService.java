package com.navtech.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.navtech.DTO.ResponseDTO;
import com.navtech.common.CommonResponse;
import com.navtech.common.SendMailAPI;
import com.navtech.entity.Arms;
import com.navtech.entity.Navtech;
import com.navtech.entity.Nullnav;
import com.navtech.repository.IArmsRepository;
import com.navtech.repository.INavtechRepository;
import com.navtech.repository.INullNavRepository;
import com.navtech.service.INavArmsIntegrateService;
import com.navtech.utils.DateUtils;

@Service
public class NavArmsIntegrateService implements INavArmsIntegrateService {

	private Logger log = Logger.getLogger(NavArmsIntegrateService.class);

	@Autowired
	IArmsRepository iArmsRepository;

	@Autowired
	INavtechRepository navtechRepository;

	@Autowired
	INullNavRepository iNullNavRepository;

	@Autowired
	CommonResponse commonResponse;

	@Autowired
	SendMailAPI sendMailAPI;

	@Override
	public void integrateARMSWithNavtech() {
		try {
			int j = 0;
			Optional<List<Arms>> dbResultArms = iArmsRepository.findByDateString(java.time.LocalDate.now().toString());
			List<Nullnav> updatedList = new ArrayList<>();
			if (dbResultArms.isPresent()) {
				/**
				 * Check
				 */
				for (int i = 0; i < dbResultArms.get().size(); i++) {
					Optional<String> ATD = Optional.ofNullable(dbResultArms.get().get(i).getAtd());
					Optional<String> ETD = Optional.ofNullable(dbResultArms.get().get(i).getEtd());
					Optional<String> STD = Optional.ofNullable(dbResultArms.get().get(i).getStd());
					Optional<String> armsFlightNumber = Optional
							.ofNullable(dbResultArms.get().get(i).getFlightNumber());
					if (armsFlightNumber.isPresent() && !isNullOrEmpty(armsFlightNumber.get())) {
						Nullnav nullnav = new Nullnav();
						nullnav.setDepartureDate(dbResultArms.get().get(i).getDepartureDate());
						nullnav.setFlightNumber(armsFlightNumber.get());
						nullnav.setDateString(java.time.LocalDate.now().toString());
						nullnav.setMailsent(false);
						/**
						 * Since STD is always present - Add this to the database - If condition just a
						 * validation
						 */
						if (STD.isPresent() && !isNullOrEmpty(STD.get())) {
							nullnav.setStd(STD.get());
						}

						if (ATD.isPresent() && !isNullOrEmpty(ATD.get())) {

							LocalDateTime parsedATD = DateUtils.convertStringToLocalDateTime(ATD.get());
							LocalDateTime now = LocalDateTime.now();
							if (parsedATD != null && parsedATD.isBefore(now)
									&& !checkForDbValue(armsFlightNumber.get())) {
								nullnav.setAtd(ATD.get());
								updatedList.add(j, nullnav);
								j++;
							}
						} else if (ETD.isPresent() && !isNullOrEmpty(ETD.get())) {

							LocalDateTime parsedETD = DateUtils.convertStringToLocalDateTime(ETD.get());
							LocalDateTime now = LocalDateTime.now();
							if (parsedETD != null && parsedETD.isBefore(now)
									&& !checkForDbValue(armsFlightNumber.get())) {
								nullnav.setEtd(ETD.get());
								updatedList.add(j, nullnav);
								j++;
							}
						} else if (STD.isPresent() && !isNullOrEmpty(STD.get())) {

							LocalDateTime parsedSTD = DateUtils.convertStringToLocalDateTime(STD.get());
							LocalDateTime now = LocalDateTime.now();
							if (parsedSTD != null && parsedSTD.isBefore(now)
									&& checkForDbValue(armsFlightNumber.get())) {
								nullnav.setStd(STD.get());
								updatedList.add(j, nullnav);
								j++;
							}
						}
					}
				}

				iNullNavRepository.saveAll(updatedList);
				/**
				 * Get the list from Null Navtech Repository
				 */
				Optional<List<Nullnav>> nullNavDbResult = iNullNavRepository
						.findByDateStringAndMailsent(java.time.LocalDate.now().toString(), false);
				if (nullNavDbResult.isPresent()) {
					List<Nullnav> uniqueListFlightDetails = nullNavDbResult.get().stream()
							.filter(distinctByKeyFlightNumber(Nullnav::getFlightNumber)).collect(Collectors.toList());
					/**
					 * Send this String as Mail Body
					 */
					if (!uniqueListFlightDetails.isEmpty()) {
						sendMailAPI.sendMailNetCoreAPI(sendMailAPI.getMailTemplate(uniqueListFlightDetails));
						/**
						 * After sending the mail set the mail sent status as true - So that the same
						 * data is not sent in other mail.Also this will help to find if navtech has
						 * provided the data or not.
						 */
						iNullNavRepository.saveAll(nullNavDbResult.get().stream().filter(setMailSentStatusAsTrue())
								.collect(Collectors.toList()));

					}

				}

			}
		} catch (Exception exception) {
			throw new RuntimeException(exception);
		}
	}

	private <T> Predicate<T> distinctByKeyFlightNumber(Function<? super T, ?> keyExtractor) {
		Set<Object> seen = ConcurrentHashMap.newKeySet();
		return t -> seen.add(keyExtractor.apply(t));
	}

	private boolean isNullOrEmpty(String str) {
		if (str != null && !str.isEmpty())
			return false;
		return true;
	}

	private boolean checkForDbValue(String armsFLightNumber) {
		try {

			Optional<Navtech> dbResultNavtech = navtechRepository.findByFlightOriginDateAndCommercialFlightNumber(
					LocalDate.now(), armsFLightNumber.replaceAll("\\s+", ""));
			return (dbResultNavtech.isPresent() && dbResultNavtech.get().getId() != null);
		} catch (Exception exception) {
			log.info("Exception Occured While NavArmsIntegration" + exception);
			return false;
		}

	}

	@Override
	public ResponseEntity<ResponseDTO> findBydateString(String dateString) {

		ResponseDTO responseDTO = new ResponseDTO();
		try {
			List<Nullnav> dbResultNullNav = iNullNavRepository.findAll();
			responseDTO = commonResponse.setResponseObject(dbResultNullNav, null);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception exception) {
			log.info("Exception Occured While Fetching Arms Details" + exception);
			return commonResponse.internalServerError(exception);
		}

	}

	private Predicate<Nullnav> setMailSentStatusAsTrue() {
		return e -> {
			e.setMailsent(true);
			return true;
		};
	}

}
