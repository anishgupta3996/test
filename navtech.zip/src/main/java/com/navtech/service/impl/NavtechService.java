package com.navtech.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.Optional;
import java.util.Vector;
import java.util.function.Predicate;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.navtech.DTO.ResponseDTO;
import com.navtech.common.CommonResponse;
import com.navtech.common.Constants;
import com.navtech.entity.Navtech;
import com.navtech.model.FlightPlan;
import com.navtech.repository.INavtechRepository;
import com.navtech.service.INavtechService;

/**
 * 
 * @author ayush.deep
 *
 */
@Service
public class NavtechService implements INavtechService {

	private Logger log = Logger.getLogger(NavtechService.class);

	@Autowired
	INavtechRepository navtechRepo;

	@Autowired
	CommonResponse commonResponse;

	@Value("${" + Constants.SFTP_HOST + "}")
	private String SFTPHost;
	@Value("${" + Constants.SFTP_USER + "}")
	private String SFTPUser;
	@Value("${" + Constants.SFTP_PORT + "}")
	private int SFTPPort;
	@Value("${" + Constants.SFTP_PASSWORD + "}")
	private String SFTPPassword;
	@Value("${" + Constants.SFTP_WORKING_DIRECTORY + "}")
	private String SFTPWorkingDIR;
	@Value("${" + Constants.SFTP_FILENAME_PREFIX + "}")
	private String SFTPFileNamePrefix;
	@Value("${" + Constants.SFTP_FILDOWNLOAD_LOCAL_PATH + "}")
	private String SFTPFileDownloadLocalPath;
	@Value("${" + Constants.SFTP_FILDOWNLOAD_LOCAL_EXTENSION + "}")
	private String SFTPFileDownloadLocalExtension;

	public void unmarshall() throws Exception {
		InputStream fileInputStream = null;
		JSch jsch = new JSch();
		Session session = null;
		ChannelSftp sftpChannel = null;

		try {
			session = jsch.getSession(SFTPUser, SFTPHost, SFTPPort);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(SFTPPassword);
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.cd(SFTPWorkingDIR);
			Vector<?> filelist = sftpChannel.ls(SFTPWorkingDIR);
			//Object object = filelist.get(0);
			for (int i = 0; i < filelist.size(); i++) {

				LsEntry entry = (LsEntry) filelist.get(i);
				String fileName = entry.getFilename();
				if (checkValidFileName(fileName)) {
					File shippingXMLInputStream = null;
					fileInputStream = null;
					fileInputStream = sftpChannel.get(fileName);
					File fileFromInputStream = File.createTempFile(SFTPFileNamePrefix, SFTPFileDownloadLocalExtension);
					try (FileOutputStream out = new FileOutputStream(fileFromInputStream)) {
						IOUtils.copy(fileInputStream, out);
					}
					shippingXMLInputStream = fileFromInputStream;
					fileFromInputStream.deleteOnExit();
					fileInputStream.close();
					try {
						unMarshallXML(shippingXMLInputStream);

					} catch (JAXBException e) {
						/**
						 * This is done to catch any exception that occurs during Unmarshalling and
						 * Continue the loop
						 */
						log.info("Exception Caught During Unmarshalling of file with file name" + fileName + "Exception"
								+ e);
						continue;

					}
				}
			}

		} catch (SecurityException | JSchException | SftpException e) {
			log.info("Exception Caught While Unmarshalling"+e);
		} catch (Exception ex) {
			log.info("Exception Caught While Unmarshalling"+ex);

		} finally {
			sftpChannel.exit();
			session.disconnect();
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					log.info("Exception Caught While Unmarshalling"+e);
				}
			}
			if (sftpChannel != null) {
				try {
					sftpChannel.exit();
				} catch (Exception e) {
					log.info("Exception Caught While Unmarshalling"+e);
				}
			}
		}

	}

	private void unMarshallXML(File shippingXMLInputStream) throws JAXBException {
		File shippingXML = shippingXMLInputStream;
		JAXBContext jc = JAXBContext.newInstance("com.navtech.model");
		Unmarshaller unmarshaller = jc.createUnmarshaller();

		FlightPlan flightPlan = (FlightPlan) JAXBIntrospector.getValue(unmarshaller.unmarshal(shippingXML));
		saveNavtechFeeds(flightPlan);

	}

	private Boolean checkValidFileName(String filename) {
		Optional<String> opt = Optional.ofNullable(filename).filter(isNameValid(filename, SFTPFileNamePrefix));
		if (opt.isPresent()) {
			/**
			 * This will return true in case the file name starts with XmlOFP_SEJTEST
			 */
			String[] checkForTestFlights = filename.split(SFTPFileNamePrefix);
			/**
			 * This length check is to avoid ArrayIndexOutOfBoundExeption
			 */
			if (checkForTestFlights.length > 1)
				return !Optional.ofNullable(checkForTestFlights[1]).filter(isNameValid(checkForTestFlights[1], "TEST"))
						.isPresent();
		}
		return opt.isPresent();

	}

	private Predicate<String> isNameValid(String xmlFileName, String prefixstring) {
		return fileName -> xmlFileName.startsWith(prefixstring);
	}

	private void saveNavtechFeeds(FlightPlan flightPlan) {
		Navtech navtech = new Navtech();
		navtech.setCommercialFlightNumber(flightPlan.getM633SupplementaryHeader().getFlight().getFlightIdentification()
				.getFlightNumber().getCommercialFlightNumber());
		navtech.setDateString(LocalDate.now().toString());
		navtech.setFlightOriginDate(flightPlan.getM633SupplementaryHeader().getFlight().getFlightOriginDate()
				.toGregorianCalendar().toZonedDateTime().toLocalDate());
		navtech.setScheduledTimeOfDeparture(flightPlan.getM633SupplementaryHeader().getFlight()
				.getScheduledTimeOfDeparture().toGregorianCalendar().toZonedDateTime().toLocalDateTime());

		/**
		 * Before saving this to the database - Check if the flight identification
		 * number is same and flight origin date is same.
		 */
		Optional<Navtech> dbResult = navtechRepo.findByFlightOriginDateAndCommercialFlightNumber(
				flightPlan.getM633SupplementaryHeader().getFlight().getFlightOriginDate().toGregorianCalendar()
						.toZonedDateTime().toLocalDate(),
				flightPlan.getM633SupplementaryHeader().getFlight().getFlightIdentification().getFlightNumber()
						.getCommercialFlightNumber());
		if (dbResult.isPresent()) {
			if (dbResult.get().getScheduledTimeOfDeparture()
					.isBefore(flightPlan.getM633SupplementaryHeader().getFlight().getScheduledTimeOfDeparture()
							.toGregorianCalendar().toZonedDateTime().toLocalDateTime())) {
				navtechRepo.delete(dbResult.get());
				navtechRepo.save(navtech);
			}

		} else {
			navtechRepo.save(navtech);
		}
	}

	@Override
	public ResponseEntity<ResponseDTO> findBydateString(String dateString) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			responseDTO = commonResponse.setResponseObject(navtechRepo.findByDateString(dateString), null);
			return new ResponseEntity<>(responseDTO, HttpStatus.OK);
		} catch (Exception exception) {
			log.info("Exception Occured While Fetching Navtech Details" + exception);
			return commonResponse.internalServerError(exception);
		}

	}
}
