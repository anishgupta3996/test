package com.navtech.service;

import org.springframework.http.ResponseEntity;

import com.navtech.DTO.ResponseDTO;

public interface INavtechService {
	void unmarshall() throws Exception;

	ResponseEntity<ResponseDTO> findBydateString(String dateString);
}
