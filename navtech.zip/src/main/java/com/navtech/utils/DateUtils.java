package com.navtech.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

	public static LocalDateTime parseMilliSeconds(Long milliSeconds) {
		return Instant.ofEpochMilli(milliSeconds).atOffset(ZoneOffset.UTC).toLocalDateTime();
	}

	public static LocalDateTime getCurrentDateTimeInUTC() {
		return LocalDateTime.now(Clock.systemUTC()).withSecond(0).withNano(0);
	}

	public static Long getMilliSeconds(LocalDateTime localDateTime) {
		Instant instant = localDateTime.toInstant(ZoneOffset.UTC);
		Date date = Date.from(instant);
		return date.getTime();
	}

	public static Long getDifferenceInSeconds(LocalDateTime localDateTime1, LocalDateTime localDateTime2) {
		return ChronoUnit.SECONDS.between(localDateTime1, localDateTime2);
	}

	public static Calendar getCalendar(LocalDateTime localDateTime) {

		Calendar calendar = Calendar.getInstance();
		calendar.set(localDateTime.getYear(), localDateTime.getMonthValue() - 1, localDateTime.getDayOfMonth(),
				localDateTime.getHour(), localDateTime.getMinute(), localDateTime.getSecond());
		return calendar;

	}

	public static LocalDateTime getStartOfDay(LocalDateTime localDateTime) {
		return localDateTime.withHour(0).withMinute(0).withSecond(0).withNano(0);
	}

	public static LocalDateTime getEndOfDay(LocalDateTime localDateTime) {
		return localDateTime.withHour(23).withMinute(59).withSecond(59).withNano(0);
	}

	public static LocalDateTime getDateTimeInUtc(Calendar calendar, String timeZone) {
		Calendar now = Calendar.getInstance();
		calendar.setTimeZone(now.getTimeZone());
		LocalDateTime localDateTime = LocalDateTime.of(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE));

		ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(timeZone));

		return parseMilliSeconds(zonedDateTime.toInstant().toEpochMilli());
	}

	public static LocalDateTime convertStringToUTC(String date) throws ParseException {
		Calendar cal = Calendar.getInstance();
		Calendar now = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
		cal.setTime(formatter.parse(date));
		cal.setTimeZone(now.getTimeZone());

		LocalDateTime localDateTime = LocalDateTime.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
				cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));

		ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of("Asia/Kolkata"));

		return parseMilliSeconds(zonedDateTime.toInstant().toEpochMilli());

	}

	public static LocalDate getDateInUtc(LocalDateTime localDateTime) {
		return LocalDate.of(localDateTime.getYear(), localDateTime.getMonth(), localDateTime.getDayOfMonth());
	}

	public static long getInitialDelayOfScheduledTask(int taskTimeHour) {
		long initialDelay;
		LocalDateTime currentDateTime = DateUtils.getCurrentDateTimeInUTC();
		LocalDateTime scheduleLocalDateTime = currentDateTime.withHour(taskTimeHour).withMinute(0);

		if (currentDateTime.isBefore(scheduleLocalDateTime)) {
			initialDelay = getDifferenceInSeconds(currentDateTime, scheduleLocalDateTime);
		} else {
			scheduleLocalDateTime = scheduleLocalDateTime.plusDays(1);
			initialDelay = getDifferenceInSeconds(currentDateTime, scheduleLocalDateTime);
		}

		return initialDelay;
	}

	/**
	 * Method added by @author ayush.deep
	 */
	public static LocalDateTime convertStringToLocalDateTime(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm");
		return LocalDateTime.parse(date, formatter);
	}

}
