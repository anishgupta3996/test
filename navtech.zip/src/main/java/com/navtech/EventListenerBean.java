/**
 * @author ayush.deep
 */
package com.navtech;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.ContextStartedEvent;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;

import com.navtech.common.Constants;
import com.navtech.service.IArmsFetchService;
import com.navtech.service.INavArmsIntegrateService;
import com.navtech.service.INavtechService;

public class EventListenerBean {

	private Logger log = Logger.getLogger(EventListenerBean.class);

	@Autowired
	private Environment environment;
	@Autowired
	INavtechService navtechService;

	@Autowired
	IArmsFetchService iArmsFetchService;

	@Autowired
	INavArmsIntegrateService iNavArmsIntegrateService;

	private ScheduledExecutorService navtechFeedExecutor = Executors.newScheduledThreadPool(1);

	private ScheduledExecutorService armsFeedExecutor = Executors.newScheduledThreadPool(1);

	private ScheduledExecutorService navtecharmsIntegrationExecutor = Executors.newScheduledThreadPool(1);

	/*
	 * The ContextStartedEvent is sent when ApplicationContext.start() is called.
	 * However SpringApplication.run() doesn't call start(), it only calls
	 * refresh(). If you want ContextStartedEvent to be sent then you'll need to
	 * start the context. For example:
	 * 
	 * public static void main(String[] args) throws Exception {
	 * SpringApplication.run(AyushExample.class, args).start(); }
	 */

	@EventListener
	public void handleContextRefreshed(ContextRefreshedEvent event) {
		navtechFeedExecutor.scheduleWithFixedDelay(navtechFeedTask, 0,
				Integer.parseInt(environment.getProperty(Constants.NAVTECH_FEED_REQUEST_SECONDS)), TimeUnit.SECONDS);
		armsFeedExecutor.scheduleWithFixedDelay(armsFeedTask, 0,
				Integer.parseInt(environment.getProperty(Constants.ARMS_FEED_REQUEST_SECONDS)), TimeUnit.SECONDS);
		navtecharmsIntegrationExecutor.scheduleWithFixedDelay(navArmsIntegrateTask, 0,
				Integer.parseInt(environment.getProperty(Constants.ARMS_NAVTECH_INTEGRATE_REQUEST_SECONDS)),
				TimeUnit.SECONDS);
	}

	@EventListener
	public void handleContextStarted(ContextStartedEvent event) {
		// Call Scheduler Every Time Start Event Is triggered
		log.info("Context Started Event" + event);
	}

	@EventListener
	public void handleContextStopped(ContextStoppedEvent event) {
		// Log This Information That Context Has Been Stopped
		log.info("Context Stopped Event" + event);
	}

	@EventListener
	public void handleContextClosed(ContextClosedEvent event) {
		// Log This Information That Context Has Been Closed
		navtechFeedExecutor.shutdown();
		armsFeedExecutor.shutdown();
		navtecharmsIntegrationExecutor.shutdown();
		log.info("Context Closed Event" + event);
	}

	private Runnable navtechFeedTask = () -> {
		try {
			navtechService.unmarshall();
		} catch (Exception exception) {
			log.info("Exception Caught During Fetch Navtech Feeds" + exception);
		}
	};

	private Runnable armsFeedTask = () -> {
		try {
			iArmsFetchService.unmarshall();
		} catch (Exception exception) {
			log.info("Exception Caught During Fetch Arms Feeds" + exception);
		}
	};

	private Runnable navArmsIntegrateTask = () -> {
		try {
			iNavArmsIntegrateService.integrateARMSWithNavtech();
		} catch (Exception exception) {
			log.info("Exception Caught During NavArmsIntegration" + exception);
		}
	};

}
