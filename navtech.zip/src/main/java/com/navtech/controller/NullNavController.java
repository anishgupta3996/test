/**
 * @author ayush.deep
 */
package com.navtech.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.navtech.DTO.ResponseDTO;
import com.navtech.service.INavArmsIntegrateService;

@RestController
@RequestMapping("/navtech")
public class NullNavController {
	Logger log = Logger.getLogger(NavtechController.class);

	@Autowired
	private INavArmsIntegrateService iNavArmsIntegrateService;

	@RequestMapping(value = "/getNullNavtech", method = RequestMethod.GET)
	public ResponseEntity<ResponseDTO> getFlightDetails() {

		return iNavArmsIntegrateService.findBydateString(java.time.LocalDate.now().toString());

	}
}
