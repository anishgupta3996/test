/**
 * @author ayush.deep
 */
package com.navtech.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.navtech.DTO.ResponseDTO;
import com.navtech.service.IArmsFetchService;

@RestController
@RequestMapping("/navtech")
public class ArmsController {
	Logger log = Logger.getLogger(ArmsController.class);

	@Autowired
	private IArmsFetchService iArmsFetchService;

	@RequestMapping(value = "/getArmsData", method = RequestMethod.GET)
	public ResponseEntity<ResponseDTO> getArmsDetails() {
		return iArmsFetchService.findBydateString(java.time.LocalDate.now().toString());

	}
}
