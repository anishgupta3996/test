package com.navtech.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.navtech.entity.Nullnav;

public interface INullNavRepository extends MongoRepository<Nullnav, BigInteger> {
	
	Optional<List<Nullnav>> findByDateStringAndMailsent(String dateString,boolean mailSent);
}
