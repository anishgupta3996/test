package com.navtech.repository;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.navtech.entity.Navtech;

public interface INavtechRepository extends MongoRepository<Navtech, BigInteger> {

	Optional<Navtech> findByFlightOriginDateAndCommercialFlightNumber(LocalDate flightOriginDate,
			String commercialFlightNumber);

	Optional<List<Navtech>> findByDateString(String dateString);

	Optional<List<Navtech>> findByCommercialFlightNumberAndDateString(String commercialFlightNumber, String dateString);

}
