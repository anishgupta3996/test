package com.navtech.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.navtech.entity.Arms;

public interface IArmsRepository extends MongoRepository<Arms, BigInteger>{
	Optional<Arms> findByDepartureDateAndFlightNumber(String departureDate,String flightNumber);
	
	Optional<List<Arms>> findByDateString(String dateString);
}
