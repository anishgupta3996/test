/**
 * @author ayush.deep
 */
package com.navtech.exception;

public class UnAuthorizedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8966586515177823178L;

	public UnAuthorizedException(String exceptionMessage) {

		super(exceptionMessage);
	}

}
