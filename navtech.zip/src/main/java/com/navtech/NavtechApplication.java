package com.navtech;

/**
 * @author ayush.deep
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

@SpringBootApplication
@EnableMongoAuditing
public class NavtechApplication {

	@Bean
	EventListenerBean customEventListener() {
		return new EventListenerBean();
	}

	public static void main(String[] args) {
		SpringApplication.run(NavtechApplication.class, args);
	}
}
